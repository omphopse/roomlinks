<?php
// routes/web.php
require_once __DIR__ . '/../controllers/HomeController.php';
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../controllers/ViewController.php';

// Parse base path from APP_URL
$parsedUrl = parse_url(APP_URL);
$basePath = isset($parsedUrl['path']) ? rtrim($parsedUrl['path'], '/') : '';

$request = $_SERVER['REQUEST_URI'];

// Remove query string
if (strpos($request, '?') !== false) {
    $request = strstr($request, '?', true);
}

// Remove base path prefix if present
if ($basePath !== '' && substr($request, 0, strlen($basePath)) === $basePath) {
    $request = substr($request, strlen($basePath));
}

switch ($request) {
    case '':
    case '/':
    case '/home':
        $controller = new HomeController();
        $controller->index();
        break;

    case '/submit-message':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $controller = new HomeController();
            $controller->submitMessage();
        } else {
            http_response_code(405);
            echo "Method Not Allowed";
        }
        break;

    case '/view':
        $controller = new ViewController();
        $controller->show();
        break;
        
    default:
        http_response_code(404);
        require_once __DIR__ . '/../404.php';
        break;
}
