/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["*.html", "*.php","views/**/*.php"], 
  theme: {
    extend: {},
  },
  plugins: [],
}