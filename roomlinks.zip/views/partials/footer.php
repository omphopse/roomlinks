<footer class="bg-[--primary-color] text-[--secondary-color] text-center py-5 mt-auto">
    <p>&copy; <span id="currentYear"></span> Copyright reserved RoomLinks | Powered By <a
            href="https://elephantroots.com/" target="_blank">ElephantRoots</a></p>
</footer>

<script>
    // Set current year in footer
    document.getElementById('currentYear').textContent = new Date().getFullYear();
</script>