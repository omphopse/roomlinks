<!-- header section starts -->
<header class="header">
    <div class="top-bar bg-[--primary-color] p-3 text-center font-semibold ">
        <h1 class="text-[--secondary-color] text-sm lg:text-lg">Find your <span class="text-[#FFF176]">Vibe,</span>
            Find your <span class="text-[#FFF176]">Flatmate</span> – it’s that <span
                class="text-[#FFF176]">Simple!</span>
        </h1>
    </div>
    <nav class="nav-bar mt-5 px-5 lg:justify-around py-5 flex justify-between items-center h-[50px]">
        <div class="logo w-50 transition-all duration-300 ease-in-out ">
            <a href="<?php echo APP_URL; ?>/">
                <h1 class="text-sm font-bold btn btn--action "><span
                        class="text-[--secondary-color] relative">RoomLinks</span></h1>
            </a>
        </div>

        <div class="btn-container font-bold relative">
            <a href="<?php echo APP_URL; ?>/#write"
                class="login bg-[--secondary-color] px-4 pr-10 py-2 rounded-[20px] mr-[-40px] hover:bg-white hover:border-2 hover:border-[--primary-color] transition-all duration-300 ease-in-out ">Write</a>
            <a href="<?php echo APP_URL; ?>/view"
                class="reg bg-[--primary-color] px-4 py-2 text-white rounded-[20px] hover:bg-white hover:border-2 hover:border-[--primary-color] transition-all duration-300 ease-in-out hover:text-black">Views</a>
        </div>
    </nav>
</header>
<!-- header section ends -->