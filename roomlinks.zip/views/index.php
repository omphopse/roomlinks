<?php require_once __DIR__ . '/../config/constants.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="styles/tailwind.css" />
    <link rel="stylesheet" href="styles/style.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free/css/all.min.css" />

    <title>RoomLinks | Offical Website</title>
</head>

<body class="flex flex-col min-h-screen">
    <div class="flex-grow">

        <?php include 'partials/header.php' ?>

        <div class="hero-content mt-10 ">
            <div class="header text-center ">
                <p class="lg:text-lg text-sm  bg-blue-200 w-fit font-medium mx-auto px-5 py-2 rounded-[30px]">More
                    than just a roommate find your vibeMate.</p>
                <h1 class="mt-5 lg:text-6xl  text-4xl font-semibold">Better <span
                        class="text-blue-600">Rooms</span>,<br> Better<span class="text-blue-600"> Roommates</span>,
                    <br> Find Yours <span class="text-blue-600">Today</span>!
                </h1>
            </div>

            <div class="input text-center mt-10">
                <div class="relative lg:w-[500px] w-[330px] mx-auto">
                    <!-- Font Awesome icon -->
                    <i class="fas fa-search text-blue-500 absolute left-4 top-1/2 -translate-y-1/2"></i>
                    <!-- Input -->
                    <input type="text" id="searchInput"
                        class="w-full pl-10 pr-4 py-2 border-2 border-blue-300 rounded-[20px] text-center focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                        placeholder="Search your home here..." value="" />
                </div>

                <div class="img lg:h-[500px] h-[300px]">
                    <img src="assets/hero-section/hero.png" class="h-[100%] mx-auto" alt="">
                </div>
            </div>
        </div>

        <!-- form section starts -->
        <section class="form-section mt-10 p-5 mb-10 text-center" id="write">

            <?php
            session_start();
            if (isset($_SESSION['success'])) {
                echo '<p class="text-green-600 font-semibold mb-4">' . htmlspecialchars($_SESSION['success']) . '</p>';
                unset($_SESSION['success']);
            }
            if (isset($_SESSION['error'])) {
                echo '<p class="text-red-600 font-semibold mb-4">' . htmlspecialchars($_SESSION['error']) . '</p>';
                unset($_SESSION['error']);
            }
            ?>

            <form id="userMessageForm" action="<?php echo APP_URL; ?>/submit-message" method="POST"
                class="max-w-md mx-auto bg-white p-6 rounded-[20px] border-2 border-blue-300 shadow-md">
                <div class="mb-4 text-left">
                    <label for="username" class="block mb-2 font-semibold text-gray-700">Username</label>
<input type="text" id="username" name="username" maxlength="20" required
                        class="w-full px-4 py-2 border-2 border-blue-300 rounded-[20px] focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                        placeholder="Enter your instagram username" />
                </div>
                <div class="mb-4 text-left">
                    <label for="message" class="block mb-2 font-semibold text-gray-700">Message </label>
                    <textarea id="message" name="message" rows="5" required
                        class="w-full px-4 py-2 border-2 border-blue-300 rounded-[20px] resize-none focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                        placeholder="Write your message here (max 200) "></textarea>
                    <p id="wordCount" class="text-sm text-gray-500 mt-1">0 / 200 words</p>
                </div>
                <button type="submit"
                    class="bg-blue-600 text-white px-6 py-2 rounded-[20px] hover:bg-blue-700 transition-colors duration-300 font-semibold">
                    Submit
                </button>
            </form>
        </section>
    </div>

    <?php include 'partials/footer.php' ?>

    <script>
        const messageInput = document.getElementById('message');
        const wordCountDisplay = document.getElementById('wordCount');
        const maxWords = 200;

        messageInput.addEventListener('input', () => {
            const words = messageInput.value.trim().split(/\s+/).filter(word => word.length > 0);
            if (words.length > maxWords) {
                messageInput.value = words.slice(0, maxWords).join(' ');
            }
            wordCountDisplay.textContent = `${Math.min(words.length, maxWords)} / ${maxWords} words`;
        });
    </script>

    <script>
        const searchInput = document.getElementById('searchInput');
        const defaultValue = "Abhi nahi, we will be live soon";

        searchInput.addEventListener('focus', () => {
            searchInput.value = defaultValue;
        });

        searchInput.addEventListener('blur', () => {
            searchInput.value = "";
        });
    </script>
</body>

</html>