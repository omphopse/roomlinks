<?php

class AdminController
{
    private $userModel;

    public function __construct($userModel)
    {
        $this->userModel = $userModel;
    }

    public function login()
    {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = $_POST['email'];
            $password = $_POST['password'];

            $user = $this->userModel->login($email, $password);

            if ($user) {
                // Start session
                session_regenerate_id(true);
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['user_role'] = $user['role'];
                $_SESSION['logged_in'] = true;

                // Redirect to admin dashboard only
                header('Location:' . APP_URL . '/admin/dashboard');
                exit();
            } else {
                $_SESSION['error'] = 'Invalid email or password';
                // Redirect back to login page
                header('Location: ' . APP_URL . '/admin-login');
                exit();
            }
        }
        // For GET requests, do nothing (let the view render the form)
    }

    public function logout()
    {
        // Destroy session
        session_destroy();
        header('Location: ' . APP_URL . '/');
        exit();
    }

    public function profile()
    {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
            header('Location: ' . APP_URL . '/admin-login');
            exit();
        }
        $userModel = $this->userModel;
        $user = $userModel->getAdminById($_SESSION['user_id']);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $newPassword = $_POST['change_password'] ?? '';
            $confirmPassword = $_POST['confirm_password'] ?? '';
            if (strlen($newPassword) < 6) {
                $_SESSION['error'] = 'Password must be at least 6 characters.';
            } elseif ($newPassword !== $confirmPassword) {
                $_SESSION['error'] = 'Passwords do not match.';
            } else {
                $updated = $userModel->updateAdminPassword($_SESSION['user_id'], $newPassword);
                if ($updated) {
                    $_SESSION['success'] = 'Password updated successfully!';
                } else {
                    $_SESSION['error'] = 'Failed to update password.';
                }
                // Refresh user data
                $user = $userModel->getAdminById($_SESSION['user_id']);
            }
        }
        include __DIR__ . '/../views/admin/profile.php';
    }
}
