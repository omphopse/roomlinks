<?php require_once __DIR__ . '/../config/constants.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="styles/tailwind.css" />
    <link rel="stylesheet" href="styles/style.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free/css/all.min.css" />

    <title>RoomLinks | Offical Website</title>

    <meta name="description" content="Find the best rooms and roommates with RoomLinks. More than just a roommate, find your vibeMate today!" />
    <meta name="keywords" content="rooms, roommates, find room, rent, RoomLinks, vibeMate, rooms in Pune, rooms in Mumbai, rooms in Delhi, rooms in Bangalore, rooms in Hyderabad, rooms in Chennai, rooms in Kolkata, rooms in Ahmedabad, rooms in Jaipur, rooms in Lucknow, rooms in Indore, rooms in Surat, rooms in Bhopal, rooms in Patna, rooms in Nagpur, rooms in Chandigarh, rooms in Noida, rooms in Gurugram, rooms in Thane, rooms in Nashik, rooms in small cities, PG in Pune, PG in Mumbai, PG in Delhi, flatmates, shared accommodation, hostel, student rooms, working professionals, affordable rooms, single room, double sharing, triple sharing, girls hostel, boys hostel, co-living, rent a room, best rooms, cheap rooms, city rooms, local rooms, room search, room booking, room rental, roommate finder, Pune, Mumbai, Delhi, Bangalore, Hyderabad, Chennai, Kolkata, Ahmedabad, Jaipur, Lucknow, Indore, Surat, Bhopal, Patna, Nagpur, Chandigarh, Noida, Gurugram, Thane, Nashik" />
    <meta name="author" content="RoomLinks" />
    <!-- Open Graph / Facebook -->
    <meta property="og:title" content="RoomLinks | Official Website" />
    <meta property="og:description" content="Find the best rooms and roommates with RoomLinks. More than just a roommate, find your vibeMate today!" />
    <meta property="og:image" content="assets/hero-section/description.png" />
    <meta property="og:url" content="https://roomlinks.in" />
    <meta property="og:type" content="website" />
    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="RoomLinks | Official Website" />
    <meta name="twitter:description" content="Find the best rooms and roommates with RoomLinks. More than just a roommate, find your vibeMate today!" />
    <meta name="twitter:image" content="assets/hero-section/description.png" />
    <!-- Canonical URL -->
    <link rel="canonical" href="https://roomlinks.in" />
</head>

<body class="flex flex-col min-h-screen">
    <div class="flex-grow">

        <?php include 'partials/header.php' ?>

        <div class="hero-content mt-10 ">
            <div class="header text-center ">
                <p class="lg:text-lg text-sm  bg-blue-200 w-fit font-medium mx-auto px-5 py-2 rounded-[30px]" title="rooms, roommates, find room, rent, RoomLinks, vibeMate, rooms in Pune, rooms in Mumbai, rooms in Delhi, rooms in Bangalore, rooms in Hyderabad, rooms in Chennai, rooms in Kolkata, rooms in Ahmedabad, rooms in Jaipur, rooms in Lucknow, rooms in Indore, rooms in Surat, rooms in Bhopal, rooms in Patna, rooms in Nagpur, rooms in Chandigarh, rooms in Noida, rooms in Gurugram, rooms in Thane, rooms in Nashik, PG in Pune, PG in Mumbai, PG in Delhi, flatmates, shared accommodation, hostel, student rooms, working professionals, affordable rooms, single room, double sharing, triple sharing, girls hostel, boys hostel, co-living, rent a room, best rooms, cheap rooms, city rooms, local rooms, room search, room booking, room rental, roommate finder">More than just a roommate find your vibeMate.</p>
                <h1 class="mt-5 lg:text-6xl  text-4xl font-semibold" title="rooms in Pune, rooms in Mumbai, rooms in Delhi, rooms in Bangalore, rooms in Hyderabad, rooms in Chennai, rooms in Kolkata, rooms in Ahmedabad, rooms in Jaipur, rooms in Lucknow, rooms in Indore, rooms in Surat, rooms in Bhopal, rooms in Patna, rooms in Nagpur, rooms in Chandigarh, rooms in Noida, rooms in Gurugram, rooms in Thane, rooms in Nashik">Better <span
                        class="text-blue-600" title="rooms, roommates, PG, flatmates, shared accommodation, hostel, student rooms, working professionals">Rooms</span>,<br> Better<span class="text-blue-600" title="roommates, flatmates, co-living, girls hostel, boys hostel"> Roommates</span>,
                    <br> Find Yours <span class="text-blue-600" title="room search, room booking, room rental, roommate finder">Today</span>!
                </h1>
            </div>

            <div class="input text-center mt-10">
                <div class="relative lg:w-[500px] w-[330px] mx-auto">
                    <!-- Font Awesome icon -->
                    <i class="fas fa-search text-blue-500 absolute left-4 top-1/2 -translate-y-1/2" title="search rooms, search roommates, search PG, search hostels"></i>
                    <!-- Input -->
                    <input type="text" id="searchInput"
                        class="w-full pl-10 pr-4 py-2 border-2 border-blue-300 rounded-[20px] text-center focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                        placeholder="Search your home here..." value="" title="find rooms in Pune, Mumbai, Delhi, Bangalore, Hyderabad, Chennai, Kolkata, Ahmedabad, Jaipur, Lucknow, Indore, Surat, Bhopal, Patna, Nagpur, Chandigarh, Noida, Gurugram, Thane, Nashik, PG, hostel, flatmates, shared accommodation" />
                </div>

                <div class="img lg:h-[500px] h-[300px]">
                    <img src="assets/hero-section/hero.png" class="h-[100%] mx-auto custom-hero-shadow" alt="roomlinks" title="rooms, roommates, PG, hostels, Pune, Mumbai, Delhi, Bangalore, Hyderabad, Chennai, Kolkata, Ahmedabad, Jaipur, Lucknow, Indore, Surat, Bhopal, Patna, Nagpur, Chandigarh, Noida, Gurugram, Thane, Nashik" />
                </div>
               
            </div>
        </div>

        <!-- form section starts -->
        <section class="form-section mt-10 p-5 mb-10 text-center" id="write">

            <?php
            session_start();
            if (isset($_SESSION['success'])) {
                echo '<p class="text-green-600 font-semibold mb-4">' . htmlspecialchars($_SESSION['success']) . '</p>';
                unset($_SESSION['success']);
            }
            if (isset($_SESSION['error'])) {
                echo '<p class="text-red-600 font-semibold mb-4">' . htmlspecialchars($_SESSION['error']) . '</p>';
                unset($_SESSION['error']);
            }
            ?>

            <form id="userMessageForm" action="<?php echo APP_URL; ?>/submit-message" method="POST"
                class="max-w-md mx-auto bg-white p-6 rounded-[20px] border-2 border-blue-300 shadow-md">
                <div class="mb-4 text-left">
                    <label for="username" class="block mb-2 font-semibold text-gray-700">Insta ID</label>
                    <input type="text" id="username" name="username" maxlength="20" required
                        class="w-full px-4 py-2 border-2 border-blue-300 rounded-[20px] focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                        placeholder="Enter your instagram username" />
                </div>
                <div class="mb-4 text-left">
                    <label for="message" class="block mb-2 font-semibold text-gray-700">Message </label>
                    <textarea id="message" name="message" rows="5" required
                        class="w-full px-4 py-2 border-2 border-blue-300 rounded-[20px] resize-none focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                        placeholder="Write your message here...."></textarea>
                    <p id="wordCount" class="text-sm text-gray-500 mt-1">0 / 200 words</p>
                </div>
                <button type="submit"
                    class="bg-blue-600 text-white px-6 py-2 rounded-[20px] hover:bg-blue-700 transition-colors duration-300 font-semibold">
                    Submit
                </button>
            </form>
        </section>
    </div>

    <!-- Connect with us section -->
    <a href="<?php echo APP_URL; ?>/contact">
        <section class="max-w-5xl lg:mx-auto mx-5 mb-16 rounded-2xl bg-white px-8 py-12 flex flex-col md:flex-row items-center justify-between relative shadow-lg border border-blue-200">
            <div class="z-10 mb-8 md:mb-0 md:mr-8 flex-1">
                <h2 class="text-3xl md:text-4xl font-bold text-blue-600 mb-3">Connect with Us</h2>
                <p class="text-lg text-gray-700 mb-4">Ready to bring your vision to life? Reach out and let's make it
                    happen!</p>
            </div>
            <a href="<?php echo APP_URL; ?>/contact"
                class="z-10 flex items-center bg-blue-600 text-white font-semibold rounded-xl px-8 py-4 shadow-md hover:bg-blue-700 transition-colors text-base flex-shrink-0">
                <i class="fas fa-phone-alt mr-3"></i>
                Contact Us
            </a>
            <!-- Decorative background shapes using root colors -->
            <div class="absolute inset-0 pointer-events-none">
                <svg class="absolute right-0 bottom-0 w-80 h-40 opacity-5" viewBox="0 0 420 180" fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <ellipse cx="340" cy="150" rx="80" ry="35" fill="#2563eb" />
                    <ellipse cx="230" cy="110" rx="50" ry="20" fill="#3b82f6" />
                    <ellipse cx="390" cy="170" rx="25" ry="10" fill="#60a5fa" />
                </svg>
                <svg class="absolute left-0 top-0 w-44 h-24 opacity-5" viewBox="0 0 220 120" fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <ellipse cx="70" cy="50" rx="50" ry="20" fill="#2563eb" />
                    <ellipse cx="150" cy="30" rx="30" ry="12" fill="#3b82f6" />
                </svg>
            </div>
        </section>
    </a>

    <?php include 'partials/footer.php' ?>

    <script>
        const messageInput = document.getElementById('message');
        const wordCountDisplay = document.getElementById('wordCount');
        const maxWords = 200;

        messageInput.addEventListener('input', () => {
            const words = messageInput.value.trim().split(/\s+/).filter(word => word.length > 0);
            if (words.length > maxWords) {
                messageInput.value = words.slice(0, maxWords).join(' ');
            }
            wordCountDisplay.textContent = `${Math.min(words.length, maxWords)} / ${maxWords} words`;
        });
    </script>

    <script>
        const searchInput = document.getElementById('searchInput');
        const defaultValue = "Abhi nahi, we will be live soon";

        searchInput.addEventListener('focus', () => {
            searchInput.value = defaultValue;
        });

        searchInput.addEventListener('blur', () => {
            searchInput.value = "";
        });
    </script>
</body>

</html>