<footer class="bg-[--primary-color] text-[--secondary-color] text-center py-5 mt-auto shadow-2xl" title="footer, rooms, roommates, PG, flatmates, shared accommodation, hostel, Pune, Mumbai, Delhi, Bangalore, Hyderabad, Chennai, Kolkata, Ahmedabad, Jaipur, Lucknow, Indore, Surat, Bhopal, Patna, Nagpur, Chandigarh, Noida, Gurugram, Thane, Nashik">
    <p title="RoomLinks, rooms in Pune, rooms in Mumbai, rooms in Delhi, PG in Bangalore, hostel in Hyderabad, flatmates in Chennai, shared accommodation in Kolkata, student rooms in Ahmedabad, working professionals in Jaipur, affordable rooms in Lucknow, single room in Indore, double sharing in Surat, triple sharing in Bhopal, girls hostel in Patna, boys hostel in Nagpur, co-living in Chandigarh, rent a room in Noida, best rooms in Gurugram, cheap rooms in Thane, city rooms in Nashik, local rooms, room search, room booking, room rental, roommate finder">&copy; <span id="currentYear"></span> Copyright reserved RoomLinks | Powered By <a
            href="https://elephantroots.com/" target="_blank" title="ElephantRoots, web development, RoomLinks partner">ElephantRoots</a></p>
</footer>

<script>
    // Set current year in footer
    document.getElementById('currentYear').textContent = new Date().getFullYear();
</script>