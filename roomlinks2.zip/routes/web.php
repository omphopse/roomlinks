<?php
// routes/web.php
require_once __DIR__ . '/../controllers/HomeController.php';
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../controllers/ViewController.php';
require_once __DIR__ . '/../controllers/ContactController.php';
require_once __DIR__ . '/../models/UserModel.php';
require_once __DIR__ . '/../controllers/AdminController.php';
require_once __DIR__ . '/../helpers/auth.php';

// Parse base path from APP_URL
$parsedUrl = parse_url(APP_URL);
$basePath = isset($parsedUrl['path']) ? rtrim($parsedUrl['path'], '/') : '';

$request = $_SERVER['REQUEST_URI'];

// Remove query string
if (strpos($request, '?') !== false) {
    $request = strstr($request, '?', true);
}

// Remove base path prefix if present
if ($basePath !== '' && substr($request, 0, strlen($basePath)) === $basePath) {
    $request = substr($request, strlen($basePath));
}

switch ($request) {
    case '':
    case '/':
    case '/home':
        $controller = new HomeController();
        $controller->index();
        break;

    case '/submit-message':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $controller = new HomeController();
            $controller->submitMessage();
        } else {
            http_response_code(405);
            echo "Method Not Allowed";
        }
        break;

    case '/view':
        $controller = new ViewController();
        $controller->show();
        break;
        
    case '/contact':
        require_once __DIR__ . '/../views/contact.php';
        break;
        
    case '/contact/submit':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $controller = new ContactController();
            $controller->submit();
        } else {
            http_response_code(405);
            echo "Method Not Allowed";
        }
        break;
        
    case '/admin-login':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $userModel = new UserModel();
            $adminController = new AdminController($userModel);
            $adminController->login();
        } else {
            require_once __DIR__ . '/../views/auth/login.php';
        }
        break;

    case '/admin/dashboard':
        checkAdminAuth();
        require_once __DIR__ . '/../views/admin/dashboard.php';
        break;
    
    case '/admin/profile':
        $controller = new AdminController(new UserModel());
        $controller->profile();
        break;
    
    case '/logout':
        $controller = new AdminController(new UserModel());
        $controller->logout();
        break;
        
    case '/admin/views':
        checkAdminAuth();
        require_once __DIR__ . '/../views/admin/views.php';
        break;
        
    default:
        http_response_code(404);
        require_once __DIR__ . '/../404.php';
        break;
}
