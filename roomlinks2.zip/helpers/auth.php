<?php

function checkAuth() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    if (empty($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
        header('Location: ' . APP_URL . '/');
        exit();
    }
}

function checkAdminAuth() {
    checkAuth();

    if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
        header('Location: ' . APP_URL . '/');
        exit();
    }
}
