<?php

class UserModel
{
    private $conn;

    public function __construct()
    {
        require_once __DIR__ . '/../config/database.php';
        $this->conn = getDatabaseConnection();
    }

    private function sanitizeInput($input)
    {
        return htmlspecialchars(strip_tags($input));
    }

    private function executeQuery($sql, $params)
    {
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            throw new Exception("Failed to prepare statement: " . $this->conn->error);
        }
        if ($params) {
            $types = str_repeat('s', count($params));
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        return $stmt;
    }

    public function login($email, $password)
    {
        $email = $this->sanitizeInput($email);

        $sql = "SELECT * FROM user WHERE email = ? AND role = 'admin'";
        $stmt = $this->executeQuery($sql, [$email]);
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                return $user;
            }
        }
        return false;
    }

    public function getAdminById($id)
    {
        $sql = "SELECT * FROM user WHERE user_id = ? AND role = 'admin'";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }

    public function updateAdminPassword($id, $newPassword)
    {
        $hash = password_hash($newPassword, PASSWORD_DEFAULT);
        $sql = "UPDATE user SET password = ? WHERE user_id = ? AND role = 'admin'";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param('si', $hash, $id);
        return $stmt->execute();
    }
}
