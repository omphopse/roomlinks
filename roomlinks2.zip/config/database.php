<?php
define('DB_HOST', 'localhost');
// define('DB_USER', 'root');
// define('DB_PASS', '');
// define('DB_NAME', 'roomlinks');
define('DB_USER', 'ktbrixzd_roomlinks');
define('DB_PASS', 'Omphopse@123');
define('DB_NAME', 'ktbrixzd_roomlinks');

function getDatabaseConnection() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    return $conn;
}
?>
