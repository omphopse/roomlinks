<?php
// Application constants
define('APP_NAME', 'Room Rental System');
// define('APP_URL', 'http://localhost/roomlinks');
define('APP_URL', 'http://phopse.online/roomlinks');
define('APP_TIMEZONE', 'Asia/Kolkata');

// File upload settings
define('MAX_FILE_SIZE', 2 * 1024 * 1024); // 2MB
define('ALLOWED_FILE_TYPES', ['image/jpeg', 'image/png', 'application/pdf']);

?>